/*
 * Copyright (c) 2008 Red Hat, Inc.
 *
 * This file is part of the Qpid async store library msgstore.so.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
 * USA
 *
 * The GNU Lesser General Public License is available in the file COPYING.
 */

#include "../unit_test.h"

#include <iostream>
#include "jrnl/arr_cnt.hpp"

using namespace boost::unit_test;
using namespace mrg::journal;
using namespace std;

QPID_AUTO_TEST_SUITE(arr_cnt_suite)

const string test_filename("_ut_arr_cnt");

QPID_AUTO_TEST_CASE(default_constructor)
{
    cout << test_filename << ".default_constructor: " << flush;
    arr_cnt a1;
    BOOST_CHECK_EQUAL(a1.size(), u_int16_t(0));
    BOOST_CHECK_EQUAL(a1.cnt(0), u_int32_t(0));
    BOOST_CHECK_EQUAL(a1.incr(0), u_int32_t(0));
    BOOST_CHECK_EQUAL(a1.decr(0), u_int32_t(0));
    BOOST_CHECK_EQUAL(a1.add(0, 100), u_int32_t(0));
    BOOST_CHECK_EQUAL(a1.sub(0, 100), u_int32_t(0));
    a1.set_cnt(0, 100);
    a1.clear_cnt(0);
    a1.clear_all();
    cout << "ok" << endl;
}

QPID_AUTO_TEST_CASE(basic_fns)
{
    cout << test_filename << ".basic_fns: " << flush;
    const u_int16_t num_elts = 8;
    arr_cnt a2;
    BOOST_CHECK_EQUAL(a2.size(), u_int16_t(0));
    a2.set_size(num_elts);
    BOOST_CHECK_EQUAL(a2.size(), num_elts);
    for (u_int16_t i=0; i<num_elts; i++)
    {
        BOOST_CHECK_EQUAL(a2.cnt(i), u_int32_t(0));
        BOOST_CHECK_EQUAL(a2.incr(i), u_int32_t(1));
        BOOST_CHECK_EQUAL(a2.decr(i), u_int32_t(0));
        BOOST_CHECK_EQUAL(a2.add(i, 100), u_int32_t(100));
        BOOST_CHECK_EQUAL(a2.sub(i, 100), u_int32_t(0));
        a2.set_cnt(i, 100);
        a2.set_cnt(i, 100);
        BOOST_CHECK_EQUAL(a2.cnt(i), u_int32_t(100));
        a2.clear_cnt(i);
        BOOST_CHECK_EQUAL(a2.cnt(i), u_int32_t(0));
        a2.set_cnt(i, i);
    }
    a2.clear_all();
    for (u_int16_t i=0; i<num_elts; i++)
        BOOST_CHECK_EQUAL(a2.cnt(i), u_int32_t(0));
    cout << "ok" << endl;
}

QPID_AUTO_TEST_CASE(resize)
{
    cout << test_filename << ".resize: " << flush;
    arr_cnt a3;
    BOOST_CHECK_EQUAL(a3.size(), u_int16_t(0));
    a3.set_size(8);
    BOOST_CHECK_EQUAL(a3.size(), u_int16_t(8));
    a3.set_size(1000);
    BOOST_CHECK_EQUAL(a3.size(), u_int16_t(1000));
    a3.set_size(4);
    BOOST_CHECK_EQUAL(a3.size(), u_int16_t(4));
    a3.set_size(0);
    BOOST_CHECK_EQUAL(a3.size(), u_int16_t(0));
    a3.set_size(10);
    BOOST_CHECK_EQUAL(a3.size(), u_int16_t(10));
    cout << "ok" << endl;
}

QPID_AUTO_TEST_CASE(resize_up_transfer_cnt)
{
    cout << test_filename << ".transfer_up: " << flush;
    const u_int16_t num_elts = 8;
    arr_cnt a4;
    a4.set_size(num_elts);
    for (u_int16_t i=0; i<num_elts; i++)
        a4.set_cnt(i, i*i);
    a4.set_size(2*num_elts);
    for (u_int16_t i=0; i<num_elts; i++)
        BOOST_CHECK_EQUAL(a4.cnt(i), u_int32_t(i*i));
    for (u_int16_t i=num_elts; i<2*num_elts; i++)
        BOOST_CHECK_EQUAL(a4.cnt(i), u_int32_t(0));
    cout << "ok" << endl;
}

QPID_AUTO_TEST_CASE(resize_down_transfer_cnt)
{
    cout << test_filename << ".transfer_up: " << flush;
    const u_int16_t num_elts = 16;
    arr_cnt a5;
    a5.set_size(num_elts);
    for (u_int16_t i=0; i<num_elts; i++)
        a5.set_cnt(i, i*i);
    a5.set_size(num_elts/2);
    for (u_int16_t i=0; i<num_elts/2; i++)
        BOOST_CHECK_EQUAL(a5.cnt(i), u_int32_t(i*i));
    cout << "ok" << endl;
}

QPID_AUTO_TEST_CASE(null_immunity_after_resize_to_zero)
{
    cout << test_filename << ".null_immunity_after_resize_to_zero: " << flush;
    arr_cnt a6;
    a6.set_size(8);
    a6.set_size(0);
    BOOST_CHECK_EQUAL(a6.size(), u_int16_t(0));
    BOOST_CHECK_EQUAL(a6.cnt(8), u_int32_t(0));
    BOOST_CHECK_EQUAL(a6.incr(8), u_int32_t(0));
    BOOST_CHECK_EQUAL(a6.decr(8), u_int32_t(0));
    BOOST_CHECK_EQUAL(a6.add(8, 100), u_int32_t(0));
    BOOST_CHECK_EQUAL(a6.sub(8, 100), u_int32_t(0));
    a6.set_cnt(8, 100);
    a6.clear_cnt(8);
    a6.clear_all();
    cout << "ok" << endl;
}

QPID_AUTO_TEST_SUITE_END()
