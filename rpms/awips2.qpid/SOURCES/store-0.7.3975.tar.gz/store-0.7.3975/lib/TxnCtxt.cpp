#include "TxnCtxt.h"

#include <sstream>
#include <unistd.h> // ::usleep()

#include "jrnl/jexception.hpp"
#include "StoreException.h"

namespace mrg {
namespace msgstore {

void TxnCtxt::completeTxn(bool commit) {
    sync();
    for (ipqItr i = impactedQueues.begin(); i != impactedQueues.end(); i++) {
        commitTxn(static_cast<JournalImpl*>(*i), commit);
    }
    impactedQueues.clear();
    if (preparedXidStorePtr)
        commitTxn(preparedXidStorePtr, commit);
}

void TxnCtxt::commitTxn(JournalImpl* jc, bool commit) {
    if (jc && loggedtx) { /* if using journal */
        boost::intrusive_ptr<DataTokenImpl> dtokp(new DataTokenImpl);
        dtokp->addRef();
        dtokp->set_external_rid(true);
        dtokp->set_rid(loggedtx->next());
        try {
            if (commit) {
                jc->txn_commit(dtokp.get(), getXid());
                sync();
            } else {
                jc->txn_abort(dtokp.get(), getXid());
            }
        } catch (const journal::jexception& e) {
            THROW_STORE_EXCEPTION(std::string("Error commit") + e.what());
        }
    }
}

// static
uuid_t TxnCtxt::uuid;

// static
IdSequence TxnCtxt::uuidSeq;

// static
bool TxnCtxt::staticInit = TxnCtxt::setUuid();

// static
bool TxnCtxt::setUuid() {
    ::uuid_generate(uuid);
    return true;
}

TxnCtxt::TxnCtxt(IdSequence* _loggedtx) : loggedtx(_loggedtx), dtokp(new DataTokenImpl), preparedXidStorePtr(0), txn(0) {
    if (loggedtx) {
//         // Human-readable tid: 53 bytes
//         // uuit_t is a char[16]
//         tid.reserve(53);
//         u_int64_t* u1 = (u_int64_t*)uuid;
//         u_int64_t* u2 = (u_int64_t*)(uuid + sizeof(u_int64_t));
//         std::stringstream s;
//         s << "tid:" << std::hex << std::setfill('0') << std::setw(16) << uuidSeq.next() << ":" << std::setw(16) << *u1 << std::setw(16) << *u2;
//         tid.assign(s.str());

        // Binary tid: 24 bytes
        tid.reserve(24);
        u_int64_t c = uuidSeq.next();
        tid.append((char*)&c, sizeof(c));
        tid.append((char*)&uuid, sizeof(uuid));
    }
}

TxnCtxt::TxnCtxt(std::string _tid, IdSequence* _loggedtx) : loggedtx(_loggedtx), dtokp(new DataTokenImpl), preparedXidStorePtr(0), tid(_tid), txn(0) {}

TxnCtxt::~TxnCtxt() { if(txn) abort(); }

#define MAX_SYNC_SLEEPS 5000 // ~1 second
#define SYNC_SLEEP_TIME 200 // 0.2 ms

void TxnCtxt::sync() {
    bool allWritten = false;
    bool firstloop = true;
    long sleep_cnt = 0L;
    while (loggedtx && !allWritten) {
        if (sleep_cnt > MAX_SYNC_SLEEPS) THROW_STORE_EXCEPTION(std::string("Error: timeout waiting for TxnCtxt::sync()"));
        if (!firstloop) {
            ::usleep(SYNC_SLEEP_TIME);
            sleep_cnt++;
        } // move this into the get events call aiolib..
        allWritten = true;
        for (ipqItr i = impactedQueues.begin(); i != impactedQueues.end(); i++) {
            sync_jrnl(static_cast<JournalImpl*>(*i), firstloop, allWritten);
        }
        if (preparedXidStorePtr)
            sync_jrnl(preparedXidStorePtr, firstloop, allWritten);
        firstloop = false;
    }
}

void TxnCtxt::sync_jrnl(JournalImpl* jc, bool firstloop, bool& allWritten) {
    try {
        if (jc && !(jc->is_txn_synced(getXid()))) {
            if (firstloop)
                jc->flush();
            allWritten = false;
            jc->get_wr_events();
        }
    } catch (const journal::jexception& e) {
        THROW_STORE_EXCEPTION(std::string("Error sync") + e.what());
    }
}

void TxnCtxt::begin(DbEnv* env, bool sync) {
    env->txn_begin(0, &txn, 0);
    if (sync)
        globalHolder = AutoScopedLock(new qpid::sys::Mutex::ScopedLock(globalSerialiser));
}

void TxnCtxt::commit() {
    if (txn) {
        txn->commit(0);
        txn = 0;
        globalHolder.reset();
    }
}

void TxnCtxt::abort(){
    if (txn) {
        txn->abort();
        txn = 0;
        globalHolder.reset();
    }
}

DbTxn* TxnCtxt::get() { return txn; }

bool TxnCtxt::isTPC() { return false; }

const std::string& TxnCtxt::getXid() { return tid; }

void TxnCtxt::addXidRecord(qpid::broker::ExternalQueueStore* queue) { impactedQueues.insert(queue); }

void TxnCtxt::complete(bool commit) { completeTxn(commit); }

bool TxnCtxt::impactedQueuesEmpty() { return impactedQueues.empty(); }

DataTokenImpl* TxnCtxt::getDtok() { return dtokp.get(); }

void TxnCtxt::incrDtokRef() { dtokp->addRef(); }

void TxnCtxt::recoverDtok(const u_int64_t rid, const std::string xid) {
    dtokp->set_rid(rid);
    dtokp->set_wstate(DataTokenImpl::ENQ);
    dtokp->set_xid(xid);
    dtokp->set_external_rid(true);
}

TPCTxnCtxt::TPCTxnCtxt(const std::string& _xid, IdSequence* _loggedtx) : TxnCtxt(_loggedtx), xid(_xid) {}

}}
