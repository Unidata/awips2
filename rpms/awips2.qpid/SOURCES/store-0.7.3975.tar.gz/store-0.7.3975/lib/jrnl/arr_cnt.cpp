/**
 * \file arr_cnt.cpp
 *
 * Qpid asynchronous store plugin library
 *
 * File containing code for class mrg::journal::arr_cnt (enqueue map). See
 * comments in file arr_cnt.hpp for details.
 *
 * \author Kim van der Riet
 *
 * Copyright (c) 2007, 2008 Red Hat Inc.
 *
 * This file is part of the Qpid async store library msgstore.so.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
 * USA
 *
 * The GNU Lesser General Public License is available in the file COPYING.
 */

#include "jrnl/arr_cnt.hpp"

#include <cassert>

namespace mrg
{
namespace journal
{

arr_cnt::arr_cnt(): _size(0), _cnt_arr_ptr(0)
{}

arr_cnt::~arr_cnt()
{
    clean(_cnt_arr_ptr, _size);
}

void
arr_cnt::set_size(const u_int16_t size)
{
    u_int16_t old_size = _size;
    u_int32_t** old_cnt_arr_ptr = _cnt_arr_ptr;
    _size = size;
    if (_size)
    {
        _cnt_arr_ptr = new u_int32_t*[_size];
        for (u_int16_t i=0; i<_size; i++)
        {
            _cnt_arr_ptr[i] = new u_int32_t;
            // transfer counts from old file array
            *_cnt_arr_ptr[i] = i < old_size ? *(old_cnt_arr_ptr[i]) : u_int32_t(0);
        }
    }
    else
        _cnt_arr_ptr = 0;
    clean(old_cnt_arr_ptr, old_size);
}

u_int32_t
arr_cnt::cnt(const u_int16_t index) const
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
        return *(_cnt_arr_ptr[index]);
    return 0;
}

u_int32_t
arr_cnt::incr(const u_int16_t index)
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
        return ++(*(_cnt_arr_ptr[index]));
    return 0;
}

u_int32_t
arr_cnt::decr(const u_int16_t index)
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
    {
        assert(*(_cnt_arr_ptr[index]) > 0);
        return --(*(_cnt_arr_ptr[index]));
    }
    return 0;
}

u_int32_t
arr_cnt::add(const u_int16_t index, u_int32_t amt)
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
    {
        *(_cnt_arr_ptr[index]) += amt;
        return *(_cnt_arr_ptr[index]);
    }
    return 0;
}

u_int32_t
arr_cnt::sub(const u_int16_t index, u_int32_t amt)
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
    {
        assert(*(_cnt_arr_ptr[index]) >= amt);
        *(_cnt_arr_ptr[index]) -= amt;
        return *(_cnt_arr_ptr[index]);
    }
    return 0;
}

void
arr_cnt::set_cnt(const u_int16_t index, u_int32_t val)
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
        *(_cnt_arr_ptr[index]) = val;
}

void
arr_cnt::clear_cnt(const u_int16_t index)
{
    assert(_size == 0 || index < _size);
    if (_cnt_arr_ptr)
        *(_cnt_arr_ptr[index]) = 0;
}

void
arr_cnt::clear_all()
{
    if (_cnt_arr_ptr)
    {
        for (u_int16_t i=0; i<_size; i++)
            *(_cnt_arr_ptr[i]) = 0;
    }
}

void
arr_cnt::clean(u_int32_t** cnt_arr_ptr, const u_int16_t size)
{
    if (cnt_arr_ptr)
    {
        for (u_int16_t i=0; i<size; i++)
        {
            if (cnt_arr_ptr[i])
            {
                delete cnt_arr_ptr[i];
                cnt_arr_ptr[i] = 0;
            }
        }
        delete[] cnt_arr_ptr;
        cnt_arr_ptr = 0;
    }
}

} // namespace journal
} // namespace mrg
