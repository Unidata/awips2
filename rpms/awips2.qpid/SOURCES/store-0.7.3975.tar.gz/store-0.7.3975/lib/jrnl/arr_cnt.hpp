/**
 * \file arr_cnt.hpp
 *
 * Qpid asynchronous store plugin library
 *
 * File containing code for class mrg::journal::arr_cnt (array counter).
 * See class documentation for details.
 *
 * \author Kim van der Riet
 *
 * Copyright (c) 2007, 2008 Red Hat Inc.
 *
 * This file is part of the Qpid async store library msgstore.so.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
 * USA
 *
 * The GNU Lesser General Public License is available in the file COPYING.
 */

#ifndef mrg_journal_arr_cnt_hpp
#define mrg_journal_arr_cnt_hpp

#include <sys/types.h>

namespace mrg
{
namespace journal
{

    /**
    * \class arr_cnt
    * \brief Class which implements a dynamically allocated array of u_int32_t counters.
    *     This is ideal where it is necessary to increment and decrement counts for an entity
    *     for which the number of elements is unknown, but for which the efficiency of a static
    *     array is required. None of the counts may go below zero.
    */

    // TODO: Replace this class with instance of std::vector<u_int32_t>
    class arr_cnt
    {
    private:
        u_int16_t   _size;
        u_int32_t** _cnt_arr_ptr;

    public:
        arr_cnt();
        virtual ~arr_cnt();

        inline u_int16_t size() const { return _size; }
        void set_size(const u_int16_t size);
        u_int32_t cnt(const u_int16_t index) const;
        u_int32_t incr(const u_int16_t index);
        u_int32_t decr(const u_int16_t index);
        u_int32_t add(const u_int16_t index, u_int32_t amt);
        u_int32_t sub(const u_int16_t index, u_int32_t amt);
        void set_cnt(const u_int16_t index, u_int32_t val);
        void clear_cnt(const u_int16_t index);
        void clear_all();
    private:
        void clean(u_int32_t** cnt_arr_ptr, const u_int16_t size);
    };

} // namespace journal
} // namespace mrg

#endif // ifndef mrg_journal_arr_cnt_hpp
