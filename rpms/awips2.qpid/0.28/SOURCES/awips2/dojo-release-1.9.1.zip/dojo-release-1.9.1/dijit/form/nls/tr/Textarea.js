//>>built
define("dijit/form/nls/tr/Textarea",({iframeEditTitle:"düzenleme alanı",iframeFocusTitle:"düzenleme alanı çerçevesi"}));
