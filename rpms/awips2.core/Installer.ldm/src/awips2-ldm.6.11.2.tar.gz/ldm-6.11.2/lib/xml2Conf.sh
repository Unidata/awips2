#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/local/ldm/runtime/lib"
XML2_LIBS="-lxml2    -lm "
XML2_INCLUDEDIR="-I/usr/local/ldm/runtime/include/libxml2"
MODULE_VERSION="xml2-2.7.7"

