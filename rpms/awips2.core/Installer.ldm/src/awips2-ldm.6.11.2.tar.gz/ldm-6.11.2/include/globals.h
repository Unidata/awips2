/*
 *   See file ../COPYRIGHT for copying and redistribution conditions.
 */
#ifndef _LDM_SERVER_GLOBAL_H
#define _LDM_SERVER_GLOBAL_H

/*
 * Unless otherwise noted, globals are
 * declared (and initialized) in ldmd.c
 */

#include <rpc/rpc.h>  /* svc_req */
#include <signal.h>   /* sig_atomic_t */

#ifdef __cplusplus
extern "C" {
#endif

extern const char *conf_path;
extern volatile sig_atomic_t done;
extern const char *logfname;
extern struct pqueue *pq;

/* timeout for rpc calls */
#ifndef DEFAULT_RPCTIMEO
#  define DEFAULT_RPCTIMEO  60
#endif
extern unsigned int rpctimeo;

/* time we sleep in pq_suspend() and before retrying connects */
extern unsigned int interval;

/*
 * Shut down a service connection that has been idle this long.
 * The keepalive timeout (for the other end) is
 * inactive_timeo/2 - 2 * interval;
 */
extern const int inactive_timeo;

/*
 * In requests,
 * we set 'from' to 'toffset' ago, and it may get
 * trimmed by  pq_clss_setfrom();
 */
#ifndef DEFAULT_OLDEST
#  define DEFAULT_OLDEST  3600
#endif
extern int max_latency;
extern int toffset;

extern void clr_pip_5(void);	        /* defined in svc5.c */
extern int read_conf(
    const char* const	conf_path,
    int			doSomething,    /* defined in parser.y */
    unsigned		defaultPort);

/*
 * Calls exit() if the "done" global variable is set; othewise, returns 1 so
 * that it can be easily used in programming loops.
 *
 * Arguments:
 *      status  Exit status for the call to exit().
 * Returns:
 *      1
 */
int exitIfDone(
    const int   status);

/*
 * Sets the path name of the product-queue.
 *
 * Arguments:
 *      path            Pointer to the path name of the product-queue.
 *                      Shall not be NULL.  Can be absolute or relative to the
 *                      current working directory.
 */
void setQueuePath(
    const char* const   path);

/*
 * Returns the path name of the product-queue.
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname of the product-queue.
 *                      Might be absolute or relative to the current working
 *                      directory.
 */
const char* getQueuePath();

/*
 * Sets the path name of the default pqact(1) configuration-file for the
 * duration of the process.
 *
 * Arguments:
 *      path            Pointer to the path name.  Shall not be NULL.  Can be
 *                      absolute or relative to the current working directory.
 */
void setPqactConfigPath(
    const char* const   path);

/*
 * Returns the path name of the default pqact(1) configuration-file.
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getPqactConfigPath();

/*
 * Sets the path name of the ldmd(1) configuration-file for the
 * duration of the process.
 *
 * Arguments:
 *      path            Pointer to the path name.  Shall not be NULL.  Can be
 *                      absolute or relative to the current working directory.
 */
void setLdmdConfigPath(
    const char* const   path);

/*
 * Returns the path name of the ldmd(1) configuration-file.
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getLdmdConfigPath();

/*
 * Sets the path name of the default pqact(1) data-directory for the
 * duration of the process.
 *
 * Arguments:
 *      path            Pointer to the path name.  Shall not be NULL.  Can be
 *                      absolute or relative to the current working directory.
 */
void setPqactDataDirPath(
    const char* const   path);

/*
 * Returns the path name of the default pqact(1) data-directory.
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getPqactDataDirPath();

/*
 * Sets the path name of the default pqsurf(1) data-directory for the
 * duration of the process.
 *
 * Arguments:
 *      path            Pointer to the path name.  Shall not be NULL.  Can be
 *                      absolute or relative to the current working directory.
 */
void setPqsurfDataDirPath(
    const char* const   path);

/*
 * Returns the path name of the default pqsurf(1) data-directory.
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getPqsurfDataDirPath();

/*
 * Sets the path name of the default pqsurf(1) output product-queue for the
 * duration of the process.
 *
 * Arguments:
 *      path            Pointer to the path name.  Shall not be NULL.  Can be
 *                      absolute or relative to the current working directory.
 */
void setSurfQueuePath(
    const char* const   path);

/*
 * Returns the path name of the default pqsurf(1) output product-queue
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getSurfQueuePath();

/*
 * Sets the path name of the default pqsurf(1) configuration-file for the
 * duration of the process.
 *
 * Arguments:
 *      path            Pointer to the path name.  Shall not be NULL.  Can be
 *                      absolute or relative to the current working directory.
 */
void setPqsurfConfigPath(
    const char* const   path);

/*
 * Returns the path name of the default pqsurf(1) configuration-file.
 *
 * Returns:
 *      NULL            Error.  "log_start()" called.
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getPqsurfConfigPath(void);

/**
 * Returns the pathname of the home of the LDM installation.
 *
 * Returns
 *      Pointer to the pathname.  Might be absolute or relative to the current
 *      working directory.
 */
const char* getLdmHomePath(void);

/**
 * Returns the pathname of the static, system-specific directory
 *
 * Returns:
 *      Pointer to the pathname.  Might be absolute or relative to the current
 *      working directory.
 */
const char* getSysConfDirPath(void);

/**
 * Returns the pathname of the registry directory.
 *
 * Returns:
 *      else            Pointer to the pathname.  Might be absolute or relative
 *                      to the current working directory.
 */
const char* getRegistryDirPath(void);

#ifdef __cplusplus
}
#endif

#endif /*!_LDM_SERVER_GLOBAL_H*/
