/*
 * See file ../COPYRIGHT for copying and redistribution conditions.
 *
 * This header-file specifies the API for the module that tracks data-requests
 * by downstream LDM processes and their corresponding upstream LDM processes.
 *
 * This implementation is designed to be used by the LDM server and its child
 * upstream LDM processes: it is not intended to be used by other, independent
 * processes.
 */

#ifndef UPSTREAM_LDM_DB_H
#define UPSTREAM_LDM_DB_H

#include <netinet/in.h>
#include <sys/types.h>
#include <ldm.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct uldb_Iter uldb_Iter;

typedef struct uldb_Entry   uldb_Entry;

typedef enum {
    /*
     * NB: The implementation depends on ULDB_SUCCESS being 0
     */
    ULDB_SUCCESS = 0,    /**< Success */
    ULDB_ARG,            /**< Invalid argument */
    ULDB_INIT,           /**< Module not initialized or already initialized */
    ULDB_EXIST,          /**< Something doesn't exist or shouldn't exist */
    ULDB_DISALLOWED,     /**< Data request not allowed */
    ULDB_SYSTEM          /**< System error. See "errno". */
} uldb_Status;

/**
 * Creates the database.
 *
 * @param path          [in] Pathname of an existing file to associate with the
 *                      database or NULL to obtain the default association.
 *                      Different pathnames obtain different databases.
 * @param capacity      [in] Initial capacity of the database in bytes
 * @retval ULDB_SUCCESS Success.
 * @retval ULDB_INIT    Database already open. log_*() called.
 * @retval ULDB_EXIST   Database already exists. log_*() called.
 * @retval ULDB_SYSTEM  System error. log_*() called.
 */
uldb_Status uldb_create(
        const char* const path,
        unsigned capacity);

/**
 * Opens the existing database.
 *
 * @param path           [in] Pathname of an existing file to associate with the
 *                       database or NULL to obtain the default association.
 *                       Different pathnames obtain different databases.
 * @retval ULDB_SUCCESS  Success.
 * @retval ULDB_INIT     Database already open. log_*() called.
 * @retval ULDB_EXIST    The database doesn't exist. log_*() called.
 * @retval ULDB_SYSTEM   System error. log_*() called.
 */
uldb_Status uldb_open(
        const char* const path);

/**
 * Closes the database, freeing any system resources. Upon successful return,
 * the database still exists but may not be accessed until uldb_open() is
 * called.
 *
 * @retval ULDB_SUCCESS  Success.
 * @retval ULDB_INIT     Database not open. log_*() called.
 * @retval ULDB_SYSTEM   System error. loc_start() called. Resulting module
 *                       state is unspecified.
 */
uldb_Status uldb_close(
        void);

/**
 * Unconditionally deletes the database.
 *
 * @param path           [in] Pathname of an existing file associated with the
 *                       database or NULL to obtain the default association.
 *                       Different pathnames obtain different databases.
 * @retval ULDB_SUCCESS  Success
 * @retval ULDB_EXIST    The database didn't exist. log_*() called.
 * @retval ULDB_SYSTEM   System error. log_*() called. Resulting module
 *                       state is unspecified.
 */
uldb_Status uldb_delete(
        const char* const path);

/**
 * Returns the number of entries in the database.
 *
 * @param size          [out] Pointer to the size of the database
 * @retval ULDB_SUCCESS Success
 * @retval ULDB_INIT    The database is closed. log_*() called.
 * @retval ULDB_SYSTEM  System error. log_*() called.
 */
uldb_Status uldb_getSize(
        unsigned* const size);

/**
 * Adds an upstream LDM feeder to the database.
 *
 * @param pid           [in] PID of upstream LDM process
 * @param protoVers     [in] Protocol version number (e.g., 5 or 6)
 * @param sockAddr      [in] Socket Internet address of downstream LDM
 * @param prodClass     [in] The data-request by the downstream LDM
 * @retval ULDB_SUCCESS     Success.
 * @retval ULDB_INIT        Module not initialized. log_*() called.
 * @retval ULDB_ARG         Invalid PID. log_*() called.
 * @retval ULDB_EXIST       Entry for PID already exists. log_*() called.
 * @retval ULDB_DISALLOWED  The request is disallowed by policy. Database not
 *                          modified. log_*() called.
 * @retval ULDB_SYSTEM      System error. log_*() called.
 */
uldb_Status uldb_addFeeder(
        const pid_t pid,
        const int protoVers,
        const struct sockaddr_in* const sockAddr,
        const prod_class* const prodClass);

/**
 * Adds an upstream LDM notifier to the database.
 *
 * @param pid           [in] PID of upstream LDM process
 * @param protoVers     [in] Protocol version number (e.g., 5 or 6)
 * @param sockAddr      [in] Socket Internet address of downstream LDM
 * @param prodClass     [in] The data-request by the downstream LDM
 * @retval ULDB_SUCCESS     Success.
 * @retval ULDB_INIT        Module not initialized. log_*() called.
 * @retval ULDB_ARG         Invalid PID. log_*() called.
 * @retval ULDB_EXIST       Entry for PID already exists. log_*() called.
 * @retval ULDB_DISALLOWED  The request is disallowed by policy. Database not
 *                          modified. log_*() called.
 * @retval ULDB_SYSTEM      System error. log_*() called.
 */
uldb_Status uldb_addNotifier(
        const pid_t pid,
        const int protoVers,
        const struct sockaddr_in* const sockAddr,
        const prod_class* const prodClass);

/**
 * Removes an entry.
 *
 * @param pid                [in] PID of upstream LDM process
 * @retval ULDB_SUCCESS      Success. Corresponding entry found and removed.
 * @retval ULDB_INIT         Module not initialized. log_*() called.
 * @retval ULDB_ARG          Invalid PID. log_*() called.
 * @retval ULDB_EXIST        No corresponding entry found. log_*() called.
 * @retval ULDB_SYSTEM       System error. See "errno". log_*() called.
 */
uldb_Status uldb_remove(
        const pid_t pid);

/**
 * Returns an iterator over a snapshot of the database at the time this
 * function is called. Subsequent changes to the database will not be reflected
 * by the iterator.
 *
 * @param iterator      [out] Address of the pointer to the iterator. The
 *                      client should call uldb_iter_free(*iterator) when the
 *                      iterator is no longer needed.
 * @retval ULDB_SUCCESS Success
 * @retval ULDB_INIT    The database is not open. log_*() called.
 * @retval ULDB_SYSTEM  System error. log_*() called.
 *
 */
uldb_Status uldb_getIterator(
        uldb_Iter** const iterator);

/**
 * Frees an iterator.
 *
 * @param iter      [in] Pointer to the iterator
 */
void uldb_iter_free(
        uldb_Iter* const iter);

/**
 * Returns the first entry.
 *
 * @param iter          [in/out] Pointer to the iterator
 * @retval NULL         There are no entries
 * @return              Pointer to the first entry
 */
const uldb_Entry* uldb_iter_firstEntry(
        uldb_Iter* const iter);

/**
 * Returns the next entry.
 *
 * @param iter          [in/out] Pointer to the iterator
 * @retval NULL         No more entries. Unspecified behavior will result from
 *                      a subsequent call to this function without an
 *                      intervening call to uldb_iter_firstEntry().
 * @return              Pointer to the next entry
 */
const uldb_Entry* uldb_iter_nextEntry(
        uldb_Iter* const iter);

/**
 * Returns the PID of an entry.
 *
 * @param entry     Pointer to the entry
 * @return          The PID of the entry
 */
pid_t uldb_entry_getPid(
        const uldb_Entry* const entry);

/**
 * Returns the protocol version (e.g., 5 or 6) of an entry.
 *
 * @param entry     Pointer to the entry
 * @return          The protocol version of the entry
 */
int uldb_entry_getProtocolVersion(
        const uldb_Entry* const entry);

/**
 * Indicates if the upstream LDM of an entry is a notifier or not.
 *
 * @param entry     Pointer to the entry
 * @retval 0        The associated upstream LDM is not sending
 *                  only data-notifications to the downstream LDM.
 * @retval 1        The associated upstream LDM is sending only
 *                  data-notifications to the downstream LDM.
 */
int uldb_entry_isNotifier(
        const uldb_Entry* const entry);

/**
 * Returns the socket Internet address of the downstream LDM associated with an
 * entry.
 *
 * @param entry     Pointer to the entry
 * @return          Pointer to the socket Internet address of the associated
 *                  downstream LDM
 */
const struct sockaddr_in* uldb_entry_getSockAddr(
        const uldb_Entry* const entry);

/**
 * Returns the product-class of an entry.
 *
 * @param entry     Pointer to the entry
 * @param prodClass [out] Address of pointer to returned product-class. The
 *                  client should call free_prod_class(*prodClass) when the
 *                  product-class is no longer needed.
 * @retval ULDB_SUCCESS Success
 * @retval ULDB_SYSTEM  System error. log_*() called.
 */
uldb_Status uldb_entry_getProdClass(
        const uldb_Entry* const entry,
        prod_class** const prodClass);

#ifdef __cplusplus
}
#endif

#endif
