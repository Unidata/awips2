#ifndef LDM4_H
#define LDM4_H

#include <rpc/rpc.h>

#ifdef __cplusplus
extern "C" {
#endif

void ldmprog_4(struct svc_req *rqstp, register SVCXPRT *transp);

#ifdef __cplusplus
}
#endif

#endif
