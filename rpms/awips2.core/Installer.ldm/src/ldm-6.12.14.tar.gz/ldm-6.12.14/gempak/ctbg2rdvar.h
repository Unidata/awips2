#ifndef _CTBG2RDVAR_H
#define _CTBG2RDVAR_H

#include <stdio.h>

#include "gemprm.h"
#include "ctbcmn.h"

void ctb_g2rdvar(char *tbname, G2vars_t *vartbl, int *iret);

#endif
