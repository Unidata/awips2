#ifndef __goes__
#define __goes__

#include <sys/types.h>
#include <zlib.h> /* Required for compress/uncompress */

int inflateFrame;
int fillScanlines;

/****
#define CHUNK_SZ 5700
#define MAXBYTES_DATA	5700	
#define	PDB_LEN	512
#define DEFAULT_COMPRESSION_LEVEL Z_DEFAULT_COMPRESSION

unsigned long int uncomprLen;
unsigned char uncomprBuf[MAXBYTES_DATA];
unsigned char uncomprBuf[MAXBYTES_DATA * MAXBYTES_DATA];

unsigned long int comprLen;
unsigned char *comprBuf;

unsigned long int comprLen;
unsigned char comprBuf[MAXBYTES_DATA];

unsigned long int comprDataLen;
unsigned char comprDataBuf[CHUNK_SZ];

int wmolen;
int nxlen;
int wmo_offset;
int nnnxxx_offset;
*****/

#endif /* __goes__ */
