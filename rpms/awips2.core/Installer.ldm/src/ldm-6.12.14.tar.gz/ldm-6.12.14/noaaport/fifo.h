/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *   See file COPYRIGHT for copying and redistribution conditions.
 */

#ifndef FIFO_H
#define FIFO_H

typedef struct fifo     Fifo;

/**
 * Returns a FIFO.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success.
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int
fifo_new(
    const size_t        npages,         /**< [in] FIFO size in pages */
    Fifo** const        fifo)           /**< [out] Pointer to pointer to be set
                                         *   to address of FIFO */;

/**
 * Frees a FIFO.
 *
 * @param[in] fifo  Pointer to FIFO to be freed.
 */
void
fifo_free(
        Fifo* const fifo);

/**
 * Transfers bytes from a file descriptor to a FIFO. Blocks until space is
 * available. This function is thread-safe with respect to `fifo_getBytes()`.
 *
 * @param[in]  fifo      FIFO.
 * @param[in]  fd        File descriptor from which to obtain bytes.
 * @param[in]  maxBytes  Maximum number of bytes to transfer.
 * @param[out] nbytes    Actual number of bytes transferred.
 * @retval     0         Success. `*nbytes` is set.
 * @retval     1         Usage error. `log_start()` called.
 * @retval     2         System error. `log_start()` called.
 * @retval     3         `fifo_close()` was called.
 */
int
fifo_readFd(
        Fifo* const restrict   fifo,
        const int              fd,
        const size_t           maxBytes,
        size_t* const restrict nbytes);

/**
 * Removes bytes from a FIFO. Blocks while insufficient data exists and
 * `fifo_close()` hasn't been called. Returns data if possible -- even if
 * `fifo_close()` has been called. This function is thread-safe with respect to
 * `fifo_readFd()`.
 *
 * @param[in] fifo    FIFO.
 * @param[in] buf     Buffer into which to put bytes.
 * @param[in[ nbytes  Number of bytes to remove.
 * @retval    0       Success.
 * @retval    1       Usage error. `log_start()` called.
 * @retval    3       `fifo_close()` was called and insufficient data exists.
 */
int
fifo_getBytes(
    Fifo* const             fifo,
    unsigned char* const    buf,
    const size_t            nbytes);

/**
 * Returns the number of times `fifo_readFd()` had to wait until sufficient
 * space was available in a FIFO and resets the counter.
 *
 * @param[in] fifo  The FIFO.
 * @return          The number of times `fifo_readFd()` had to wait.
 */
size_t
fifo_getFullCount(
        Fifo* const fifo);

/**
 * Closes a FIFO.
 *
 * This function is thread-safe and idempotent.
 *
 * @param[in] fifo  FIFO to be closed.
 */
void
fifo_close(
    Fifo* const fifo)       /**< [in/out] Pointer to FIFO */;

#endif
