/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *   See file COPYRIGHT for copying and redistribution conditions.
 */

#ifndef MULTICAST_READER_H
#define MULTICAST_READER_H

#include "reader.h"

/**
 * Returns a new NOAAPORT reader.
 *
 * This function is thread-safe.
 *
 * @param[our] reader     The returned reader.
 * @param[in]  mcastSpec  IPv4 address of the NOAAPORT multicast group.
 * @param[in]  ifaceSpec  IPv4 address of the interface on which to listen for
 *                        multicast packets or NULL to listen on all available
 *                        interfaces.
 * @param[in]  fifo       Pointer to the FIFO into which to write data.
 * @retval     0          Success. `*reader` is set.
 * @retval     1          Usage failure. `log_start()` called.
 * @retval     2          System failure. `log_start()` called.
 */
int mcastReader_new(
    Reader** const      reader,
    const char* const   mcastSpec,
    const char* const   ifaceSpec,
    Fifo* const         fifo);

#endif
