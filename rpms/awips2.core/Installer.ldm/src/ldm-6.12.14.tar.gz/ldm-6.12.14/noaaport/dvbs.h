#ifndef __dvbs_ids__
#define __dvbs_ids__

#define MAX_DVBS_PID 10               /* eg no 224.0.1.10 */
unsigned short s_port[] = { 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210 };

#endif
