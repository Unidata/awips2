#ifndef _ABBR_H_
#define _ABBR_H_
/*
 *   Copyright 1995, University Corporation for Atmospheric Research
 *   See ../COPYRIGHT file for copying and redistribution conditions.
 */
/* $Id: abbr.h,v 1.1 1995/07/05 19:14:50 davis Exp $ */

extern void
set_abbr_ident(const char *remote, const char *postfix);

#endif /* !_ABBR_H_ */
