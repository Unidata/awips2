#ifndef FEEDTYPE_XML_H
#define FEEDTYPE_XML_H

typedef enum {
    FX_SUCCESS = 0,
    FX_OPEN_ERROR,
    FX_SYSTEM_ERROR,
    FX_DATABASE_ERROR,
    FX_PARSE_ERROR
}	FeedtypeXmlError;

#endif
