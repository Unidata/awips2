/*
 * CommUtil.cpp
 *
 *  Created on: Jan 7, 2012
 *      Author: jie
 */

#include "CommUtil.h"

