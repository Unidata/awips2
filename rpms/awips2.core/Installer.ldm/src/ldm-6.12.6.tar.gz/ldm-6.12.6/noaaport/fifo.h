/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *   See file COPYRIGHT for copying and redistribution conditions.
 */

#ifndef FIFO_H
#define FIFO_H

typedef struct fifo     Fifo;

/**
 * Returns a FIFO.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success.
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int fifoNew(
    const size_t        npages,         /**< [in] FIFO size in pages */
    Fifo** const        fifo)           /**< [out] Pointer to pointer to be set
                                         *   to address of FIFO */;

/**
 * Reserves space in a FIFO and returns a pointer to it. Blocks until the
 * requested amount of space is available. The client should subsequently call
 * \link fifoUpdate() \endlink when the space has been written into or \link
 * fifoCopy() \endlink. Only one thread can execute this function and the
 * subsequent \link fifoUpdate() \endlink or \link fifoCopy() \endlink at a
 * time.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success. \c *bytes points to at least \c nbytes of memory.
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S error. \c log_start() called.
 * @retval 3    FIFO is closed.
 */
int fifoWriteReserve(
    Fifo* const             fifo,       /**< [in/out] Pointer to the FIFO */
    const size_t            nbytes,     /**< [in] The amount of space to
                                         *   reserve */
    unsigned char** const   buf,        /**< [out] Pointer to the pointer to be
                                         *   set to the address of the reserved
                                         *   space */
    size_t* const           size)       /**< [out] Amount of data, in bytes, 
                                         *   that can be initially transferred.
                                         *   If less than \e nbytes, then the
                                         *   user must subsequently call
                                         *   \c fifoCopy(); otherwise, the user
                                         *   may call \c fifoCopy() or \c
                                         *   write into \e buf and then call
                                         *   \c fifoWriteUpdate(). */;

/**
 * Updates the FIFO based on a successful write to the space obtained from
 * \link fifoWriteReserve() \endlink. This function must be called by the
 * thread that returned from the previous call to \link fifoWriteReserve()
 * \endlink. 
 *
 * This function in thread-safe.
 *
 * @retval 0    Success
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S error. \c log_start() called.
 */
int fifoWriteUpdate(
    Fifo* const     fifo,   /**< [in/out] Pointer to FIFO */
    const size_t    nbytes) /**< [in] The number of bytes actually written */;

/**
 * Copies bytes into the fifo.  This function must be called by the thread that
 * returned from the previous call to \link fifoWriteReserve() \endlink. 
 *
 * @retval 0    Success
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S error. \c log_start() called.
 */
int fifoCopy(
    Fifo* const             fifo,   /**< [in] The FIFO */
    unsigned char* const    buf,    /**< [in] The buffer to copy from */
    const size_t            nbytes) /**< [in] The number of bytes to copy */;

/**
 * Returns a pointer to the next FIFO region to be read from. Blocks until
 * sufficient data exists. Only one thread can execute this function and the
 * subsequent \link fifoReadUpdate() \endlink at a time.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S error. \c log_start() called.
 * @retval 3    FIFO is closed.
 */
int fifoRead(
    Fifo* const             fifo,   /**< [in/out] Pointer to FIFO */
    unsigned char* const    buf,    /**< [out] Buffer into which to put data */
    const size_t            nbytes) /**< [in] The number of bytes to be read */;

/**
 * Closes a FIFO when it becomes empty. Attempting to write to or read from a
 * closed FIFO will result in an error. Blocked \link fifoWriteReserve() 
 * \endlink and \link fifoRead() \endlink operations will error-return.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S error. \c log_start() called.
 */
int fifoCloseWhenEmpty(
    Fifo* const fifo)       /**< [in/out] Pointer to FIFO */;

#endif
