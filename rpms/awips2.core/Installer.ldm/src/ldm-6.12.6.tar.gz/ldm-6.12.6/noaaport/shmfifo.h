/*
 * ShmFIFO.h
 *
 * Shared Memory FIFO Pipe implementation library
 *
 * Copyright 2004 Yaroslav Polyakov.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#ifndef SHMFIFO_H
#define SHMFIFO_H

struct shmhandle
{
   int sid;
   void *mem;
   int privsz; /* size of single priv structure of upper program */
   int semid; /* semaphore id */
   int sz;    /* size of shared mem in bytes */
};

struct shmprefix
{  int counter;
   int read;  /* offsets from shm->mem where we should read and write */
   int write; /* min value for both is shm->privsz+sizeof(struct shmprefix) */
   int sz;
   int privsz;
};

struct shmbh /* shmem block header */
{
   int sz;
   unsigned canary;
};

#if ! ( _NO_XOPEN4 && _NO_XOPEN5 ) && !defined(_DARWIN_C_SOURCE)
union semun {
    int                 val;
    struct semid_ds*    buf;
    unsigned short int* array;
    struct seminfo*     __buf;
};
#endif

/* Public functions */
/**
 * Returns an allocated, shared-memory structure. The returned structure is
 * unset: it doesn't reference a shared-memory FIFO. The client should call
 * \link shmfifo_free() \endlink when the structure is no longer needed.
 *
 * @retval !NULL        Pointer to an allocated shared-memory structure.
 * @retval NULL         Failure. An error message is logged.
 */
struct shmhandle* shmfifo_new(void);

/**
 * Frees a shared-memory structure allocated by \link shmfifo_new() \endlink.
 *
 * @param shm   Pointer to the shared-memory structure to be freed. May be
 *              NULL.
 */
void shmfifo_free(
    struct shmhandle* const    shm);

void
shmfifo_setpriv (struct shmhandle *shm, void *priv);

void
shmfifo_getpriv (struct shmhandle *shm, void *priv);

/**
 * Sets a data-structure so that it references the shared-memory FIFO
 * associated with a (partial) key.
 *
 * @retval  0   Success. The data-structure is initialized and references the
 *              shared-memory FIFO.
 * @retval -1   \e shm is \c NULL. An error message is logged.
 * @retval -2   \e nkey is \c -1.
 * @retval -3   The shared-memory FIFO doesn't exist.
 * @retval -4   The shared-memory FIFO couldn't be accessed. An error message
 *              is logged.
 */
int shmfifo_shm_from_key(
    struct shmhandle* const     shm,    /**< Pointer to the data-structure to
                                         * be set. */
    const int                   nkey)   /**< The (partial) key associated with
                                         * the shared-memory FIFO. */;

/**
 * Returns a data-structure for accessing a shared-memory FIFO. Creates the
 * FIFO is it doesn't already exist.
 *
 * @retval !NULL        Pointer the data-structure for accessing the
 *                      shared-memory FIFO.
 * @retval NULL         Failure. An error message is logged.
 */
struct shmhandle* shmfifo_create(
    const int   npages,         /**< size of the FIFO in pages */
    const int   privsz,         /**< <size of the private portion of the FIFO
                                 in bytes */
    const int   nkey)           /**< Partial key associated with the FIFO  or
                                 \c -1 to obtain a private, shared-memory
                                 FIFO. */;

/**
 * Attaches a data-structure to its shared-memory FIFO.
 *
 * @retval  1   Success.
 * @retval -1   The data-structure is already attached to a shared-
 *              memory FIFO. An error message is logged.
 * @retval -1   The shared-memory FIFO reference by \e shm couldn't be
 *              attached. An error message is logged.
 */
int shmfifo_attach(
    struct shmhandle* const     shm)    /**< Pointer to the data-structure. */;

int
shmfifo_empty (struct shmhandle *shm);

void
shmfifo_detach (struct shmhandle *shm);

/*
 * Reads one record's worth of data from the FIFO and writes it to a
 * client-supplied buffer. Blocks until data is available.
 *
 * Arguments:
 *      shm             Pointer to the shared-memory FIFO data-structure. The
 *                      FIFO must be unlocked.
 *      data            Pointer to the buffer into which to put data from the
 *                      FIFO.
 *      sz              The size of the buffer in bytes.
 *      nbytes          Pointer to the memory location to be set to the number
 *                      of bytes read.
 * Returns:
 *      0               Success. "*nbytes" is set to the number of bytes read.
 *      ECANCELED       Operating-system failure. Error-message logged.
 *      EINVAL          "shm" uninitialized. Error-message logged.
 *      EINVAL          "sz" is non-positive. Error-message logged.
 *      EINVAL          The buffer is too small for the record's data.  No data
 *                      is read.  Error-message logged.
 *      EIO             FIFO is corrupt. Error-message logged.
 * Raises:
 *      SIGSEGV if "shm" is NULL
 *      SIGSEGV if "data" is NULL
 *      SIGSEGV if "nbytes" is NULL
 *      SIGABRT if "shm" is uninitialized
 */
int
shmfifo_get(
    const struct shmhandle* const       shm,
    void* const                         data,
    const int                           sz,
    int* const                          nbytes);

/*
 * Writes data to the shared-memory FIFO.
 *
 * Arguments:
 *      shm             Pointer to the shared-memory FIFO data-structure.
 *      data            Pointer to the data to be written.
 *      sz              The amount of data to be written in bytes.
 * Returns:
 *      0               Success.
 *      E2BIG           "sz" is larger than the FIFO can handle.  Error-message
 *                      logged.
 *      ECANCELED       Operating-system failure. Error-message logged.
 *      EIO             I/O error. Error-message logged.
 *      EINVAL          "sz" is negative. Error-message logged.
 *      EINVAL          "shm" uninitialized. Error-message logged.
 */
int
shmfifo_put(
    const struct shmhandle* const       shm,
    void* const                         data,
    const int                           sz);

void
shmfifo_dealloc (struct shmhandle *shm);

#endif
