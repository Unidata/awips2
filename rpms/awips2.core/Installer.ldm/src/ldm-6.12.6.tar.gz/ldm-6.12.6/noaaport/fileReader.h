/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *   See file COPYRIGHT for copying and redistribution conditions.
 */

#ifndef FILE_READER_H
#define FILE_READER_H

#include "reader.h"

/**
 * Returns a new file-reader.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success.
 * @retval 1    Precondition failure. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int fileReaderNew(
    const char* const   pathname,   /**< [in] Pathname of file to read or
                                      *  NULL to read standard input stream */
    Fifo* const         fifo,       /**< [in] Pointer to FIFO into which to put
                                      *  data */
    Reader** const      reader)     /**< [out] Pointer to pointer to address of
                                      *  reader */;

#endif
