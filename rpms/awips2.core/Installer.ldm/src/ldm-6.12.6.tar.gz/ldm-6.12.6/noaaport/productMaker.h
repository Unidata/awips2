/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *   See file COPYRIGHT for copying and redistribution conditions.
 */

#ifndef WRITER_H
#define WRITER_H

typedef struct productMaker   ProductMaker;

/**
 * Returns a new product-maker.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success.
 * @retval 1    Usage failure. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int pmNew(
    Fifo* const             fifo,           /**< [in] Pointer to FIFO from
                                              *  which to get data */
    LdmProductQueue* const  lpq,            /**< [in] LDM product-queue into
                                              *  which to put data-products */
    ProductMaker** const    productMaker)   /**< [out] Pointer to pointer to
                                              *  returned product-maker */;

/**
 * Executes a product-maker.
 *
 * This function is thread-compatible but not thread-safe.
 *
 * @retval (void*)0    The FIFO was closed.
 * @retval (void*)1    Usage failure. \c log_start() called.
 * @retval (void*)2    O/S failure. \c log_start() called.
 * @retval (void*)-1   Retransmission failure. \c log_start() called.
 */
void* pmStart(
    void* const         arg)          /**< [in/out] Pointer to the
                                        *  product-maker to be executed */;

/**
 * Returns statistics since the last time this function was called or \link
 * pmStart() \endlink was called.
 */
void pmGetStatistics(
    ProductMaker* const     productMaker,       /**< [in] Pointer to the
                                                  *  product-maker */
    unsigned long* const    packetCount,        /**< [out] Number of packets */
    unsigned long* const    missedPacketCount,  /**< [out] Number of missed
                                                  *  packets */
    unsigned long* const    prodCount)          /**< [out] Number of products 
                                                  *  inserted into the
                                                  *  product-queue */;

/**
 * Returns the termination status of a product-maker
 *
 * This function is thread-compatible but not thread-safe.
 *
 * @retval 0    The FIFO was closed.
 * @retval 1    Usage failure. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int pmStatus(
    ProductMaker* const productMaker)   /**< [in] Pointer to the product-maker
                                          */;

#endif
