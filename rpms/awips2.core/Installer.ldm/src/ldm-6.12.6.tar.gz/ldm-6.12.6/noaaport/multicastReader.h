/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *   See file COPYRIGHT for copying and redistribution conditions.
 */

#ifndef MULTICAST_READER_H
#define MULTICAST_READER_H

#include "reader.h"

/**
 * Returns a new UDP-reader.
 *
 * This function is thread-safe.
 *
 * @retval 0    Success.
 * @retval 1    Usage failure. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int multicastReaderNew(
    const char* const   mcastSpec,  /**< [in] Multicast group in IPv4 dotted-
                                      *  quad format */
    const char* const   interface,  /**< [in] IPv4 address of interface on which
                                      *  to listen for multicast UDP packets
                                      *  in IPv4 dotted-quad format or NULL to
                                      *  listen on all available interfaces */
    Fifo* const         fifo,       /**< [in] Pointer to FIFO into which to
                                      *  write data */
    Reader** const      reader)     /**< [out] Pointer to pointer to address of
                                      *  returned reader */;

#endif
