/*
 *   Copyright 2011, University Corporation for Atmospheric Research.
 *
 *   See file COPYRIGHT in the top-level source-directory for copying and
 *   redistribution conditions.
 */

#ifndef CHILD_MAP_H
#define CHILD_MAP_H

typedef struct child_map     ChildMap;

#ifdef __cplusplus
    extern "C" {
#endif

/**
 * Returns a new instance of a child-map.
 *
 * @retval NULL         Failure. \c log_start() called.
 * @retval !NULL        Pointer to a new instance.
 */
ChildMap* cm_new(void);

/**
 * Frees a child-map.
 */
void cm_free(
    ChildMap* const     map)            /**< [in] Pointer to the child-map or
                                         *   NULL */;

/*
 * Adds an entry to a child-map.
 *
 * @retval 0    Success
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int cm_add_string(
    ChildMap* const     map,            /**< [in/out] Pointer to the child-map
                                         */
    const pid_t         pid,            /**< [in] Process ID of the child.
                                         *   Must not already exist in map. */
    const char* const   command)        /**< [in] Command-line of the child.
                                         *   Defensively copied. */;

/*
 * Adds an entry to a child-map.
 *
 * @retval 0    Success
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    O/S failure. \c log_start() called.
 */
int cm_add_argv(
    ChildMap* const             map,    /**< [in/out] Pointer to the child-map
                                         */
    const pid_t                 pid,    /**< [in] Process ID of the child.
                                         *   Must not already exist in map. */
    const char* const* const    argv)   /**< [in] Command-line of the child in
                                         *   argument vector form. Last pointer
                                         *   must be NULL. The strings are
                                         *   defensively copied. */;

/**
 * Indicates if a child-map contains a particular entry.
 *
 * @retval 1    Yes, the child is in the child-map.
 * @retval 0    No, the child isn't in the child-map or \c map is \c NULL.
 */
int cm_contains(
    const ChildMap* const       map,    /**< [in] Pointer to the child-map */
    const pid_t                 pid)    /**< [in] Process ID of the child */;

/**
 * Returns the command-line of an entry in a child-map.
 *
 * @retval NULL         \c map is \c NULL or the corresponding entry doesn't
 *                      exist
 * @retval !NULL        The command-line of the corresponding entry. Calling
 *                      \c cm_remove() on entry \c pid before dereferencing
 *                      this pointer results in undefined behavior.
 */
const char* cm_get_command(
    const ChildMap* const       map,    /**< [in] Pointer to the child-map */
    const pid_t                 pid)    /**< [in] Process ID of the child */;

/**
 * Removes an entry from a child-map.
 *
 * @retval 0    Success. The entry was removed.
 * @retval 1    Usage error. \c log_start() called.
 * @retval 2    The entry wasn't in the map.
 */
int cm_remove(
    ChildMap* const     map,    /**< [in/out] Pointer to the child-map */
    const pid_t         pid)    /**< [in] Process ID of the entry to be removed
                                 */;

/**
 * Returns the number of entries in a child-map.
 *
 * @return The number of entries in the child-map.
 */
unsigned cm_count(
    const ChildMap* const       map)    /**< [in] Pointer to the child-map or
                                         *   NULL, in which case \c 0 is 
                                         *   returned. */;

#ifdef __cplusplus
    }
#endif

#endif
