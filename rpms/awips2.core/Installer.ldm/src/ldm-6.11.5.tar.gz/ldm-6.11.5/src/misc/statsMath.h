#ifndef STATS_MATH_H
#define STATS_MATH_H

extern double	sumBinomCoeff(
    unsigned	n,
    unsigned	k);

#endif
