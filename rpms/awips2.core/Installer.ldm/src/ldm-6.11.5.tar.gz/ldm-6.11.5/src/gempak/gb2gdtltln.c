#include "gb2def.h"
#include "proto_gemlib.h"

void gb2_gdtltln( float *navblk, int *igdtmpl, int *iret )
/************************************************************************
 * gb2_gdtltln								*
 *                                                                      *
 * This routine converts a CED Gempak grid navigation block to a        *
 * GRIB2 Grid Definition Template 3.0.					*
 *                                                                      *
 * gb2_gdtltln ( navblk, igdtmpl, iret )				*
 *									*
 * Input parameters:                                                    *
 *  *navblk   		float       Decoded GRIB2 structure             *
 *									*
 * Output parameters:                                                   *
 *  *igdtmpl            int        GDT 3.0 values 			*
 *  *iret               int        Return code                          *
 *                                    -36 = Projection not CED		*
 **                                                                     *
 * Log:                                                                 *
 * S. Gilbert/NCEP          08/05    Calculations taken from GDS_CED    *
 * S. Gilbert/NCEP          03/06    Chngs to remove compiler warnings  *
 ***********************************************************************/
{

        double     rlat1, rlon1, rlat2, rlon2, dx, dy;

        int        ier;
        int        nx, ny;

/*---------------------------------------------------------------------*/
	*iret = 0;

        /*
         *  ensure grid navigation block is CED
         */
        if ( strncmp( (char *)(navblk+1), "CED", 3) != 0 ) {
           *iret=-36;
           ER_WMSG("GB", iret, (char *)(navblk+1), &ier, 2, 4 );
        }

        nx = G_NINT(navblk[4]);
        ny = G_NINT(navblk[5]);
        rlat1 = navblk[6];
        rlon1 = navblk[7];
        rlat2 = navblk[8];
        rlon2 = navblk[9];

        /*
         *  Set Grid Definition Template
         */

        igdtmpl[0] = 1;                       /* Earth Assumed Spherical */
        igdtmpl[1] = 0;                       /* Radius scale factor     */
        igdtmpl[2] = G_NINT(RADIUS);          /* Radius of Earth         */
        igdtmpl[3] = 0;                       /* Oblate info     n/a     */
        igdtmpl[4] = 0;                       /* Oblate info     n/a     */
        igdtmpl[5] = 0;                       /* Oblate info     n/a     */
        igdtmpl[6] = 0;                       /* Oblate info     n/a     */
        igdtmpl[7] = nx;                      /* Kx                      */
        igdtmpl[8] = ny;                      /* Kx                      */
        igdtmpl[9] = 0;                       /* Basic Angle             */
        igdtmpl[10] = 0;                      /* Subdivision             */
        igdtmpl[11] = G_NINT(rlat1*1000000.0);
                                              /* Lat of 1st grid point   */
        if ( rlon1 < 0.0 ) rlon1 += 360.0;
        igdtmpl[12] = G_NINT(rlon1*1000000.0);   
                                              /* Lon of 1st grid point   */
        igdtmpl[13] = 48;                     /* Res and Comp flags      */
        igdtmpl[14] = G_NINT(rlat2*1000000.0);
                                              /* Lat of last grid point  */
        if ( rlon2 < 0.0 ) rlon2 += 360.0;
        igdtmpl[15] = G_NINT(rlon2*1000000.0);   
                                              /* Lon of last grid point  */

        dx = (rlon2 - rlon1) / (nx-1);
        igdtmpl[16] = G_NINT(dx*1000000.0);   /* Dx                   */
        dy = (rlat2 - rlat1) / (ny-1);
        igdtmpl[17] = G_NINT(dy*1000000.0);   /* Dy                   */
        igdtmpl[18] = 64;                     /* Scanning mode           */

}
