/*
 * The data-product abstraction.
 *
 * See file ../COPYRIGHT for copying and redistribution conditions.
 */
#ifndef DATA_PROD_H
#define DATA_PROD_H

#include "ldm.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Returns the nil data-product.
 *
 * @return  The nil data-product.
 */
const product* dp_getNil(
        void);

/**
 * Indicates if two data-products are equal.
 *
 * @param prod1     [in] The first data-product.
 * @param prod2     [in] The second data-product.
 * @retval 0        The data-products are unequal.
 * @retval 1        The data-products are equal.
 */
int dp_equals(
        const product* const prod1,
        const product* const prod2);

/**
 * Indicates if a data-product is the nil data-product.
 *
 * @param prod      [in] The data-product to be checked.
 * @retval 0        The data-product is not the nil data-product.
 * @retval 1        The data-product is the nil data-product.
 */
int dp_isNil(
        const product* const prod);

#ifdef __cplusplus
}
#endif

#endif
