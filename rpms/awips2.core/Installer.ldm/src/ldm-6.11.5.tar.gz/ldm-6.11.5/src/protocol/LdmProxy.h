/*
 *   See file ../COPYRIGHT for copying and redistribution conditions.
 *
 *   This header-file specifies the API for the "send" module.
 */
#ifndef LDMPROXY_H
#define LDMPROXY_H

#include <ldm.h>

typedef struct ldmProxy LdmProxy;

typedef enum {
    LP_OK = 0,                  /* OK */
    LP_SYSTEM,                  /* system error */
    LP_TIMEDOUT,                /* timed out */
    LP_HOSTUNREACH,             /* host is unreachable */
    LP_RPC_ERROR,               /* error in the RPC layer */
    LP_LDM_ERROR,               /* LDM error */
    LP_UNWANTED                 /* data-product isn't wanted */
} LdmProxyStatus;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Sets the RPC timeout used by all subsequently-create LDM proxies.
 *
 * Arguments:
 *      timeout         The RPC timeout in seconds.
 */
void
lp_setRpcTimeout(
    const unsigned      timeout);

/*
 * Returns a new instance of an LDM proxy. Can take a while because it
 * establishes a connection to the LDM.
 *
 * Arguments:
 *      host            Identifier of the host on which an LDM server is
 *                      running.
 *      instance        Pointer to a pointer to the new instance. "*instance"
 *                      is set upon successful return.
 * Returns:
 *      0               Success. "*instance" is set.
 *      LP_SYSTEM       System error. "log_start()" called.
 *      LP_TIMEDOUT     Connection attempt timed-out. "log_start()" called.
 *      LP_HOSTUNREACH  Host is unreachable. "log_start()" called.
 *      LP_RPC_ERROR    RPC error. "log_start()" called.
 *      LP_LDM_ERROR    LDM error. "log_start()" called.
 */
LdmProxyStatus
lp_new(
    const char* const   host,
    LdmProxy** const    instance);

/*
 * Frees an instance.
 *
 * Arguments:
 *      proxy           Pointer to the instance to be freed or NULL.
 */
void
lp_free(
    LdmProxy* const     proxy);

/*
 * Returns the identifier of the host.
 *
 * Arguments:
 *      proxy           Pointer to the LDM proxy data-structure.
 * Returns:
 *      The identifier of the host.
 */
const char*
lp_host(
    const LdmProxy* const       proxy);

/*
 * Returns the protocol version.
 *
 * Arguments:
 *      proxy           Pointer to the LDM proxy data-structure.
 * Returns:
 *      The protocol version.
 */
unsigned int
lp_version(
    const LdmProxy* const       proxy);

/*
 * Notifies the LDM of the class of data-products that will be sent.
 *
 * Arguments:
 *      proxy           Pointer to the LDM proxy structure.
 *      offer           Pointer to the data-product class structure which will
 *                      be offered to the LDM.
 *      want            Pointer to a pointer to a data-product class structure.
 *                      "*want" will be set to the data-product class structure
 *                      that the LDM wants. The client should call
 *                      "free_prod_class(*want)" when the product-class is no
 *                      longer needed.
 * Returns:
 *      0               Success. "*want" is set.
 *      LP_TIMEDOUT     The RPC call timed-out. "log_start()" called.
 *      LP_RPC_ERROR    RPC error. "log_start()" called.
 *      LP_LDM_ERROR    LDM error. "log_start()" called.
 */
LdmProxyStatus
lp_hiya(
    LdmProxy* const             proxy,
    prod_class_t* const         offer,
    prod_class_t** const        want);

/*
 * Sends a data-product to the LDM.
 *
 * Arguments:
 *      proxy           Pointer to the LDM proxy data-structure.
 *      product         Pointer to the data-product to be sent.
 * Returns:
 *      0               Success.
 *      LP_UNWANTED     The data-product wasn't wanted by the LDM.
 *      LP_TIMEDOUT     The RPC call timed-out. "log_start()" called.
 *      LP_RPC_ERROR    RPC error. "log_start()" called.
 *      LP_LDM_ERROR    LDM error. "log_start()" called.
 */
LdmProxyStatus
lp_send(
    LdmProxy*           proxy,
    product* const      product);

/*
 * Flushes the connection to the LDM.
 *
 * Arguments:
 *      proxy           Pointer to the LDM proxy data-structure.
 * Returns:
 *      0               Success.
 *      LP_TIMEDOUT     The RPC call timed-out. "log_start()" called.
 *      LP_RPC_ERROR    RPC error. "log_start()" called.
 */
LdmProxyStatus
lp_flush(
    LdmProxy*           proxy);

#ifdef __cplusplus
}
#endif

#endif
