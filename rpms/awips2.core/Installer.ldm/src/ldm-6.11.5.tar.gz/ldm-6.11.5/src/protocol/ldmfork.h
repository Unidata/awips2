/*
 *   See file ../COPYRIGHT for copying and redistribution conditions.
 *
 *   This header-file specifies the API for the ldmfork() function.
 */
#ifndef LDMFORK_H
#define LDMFORK_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Forks the current process in the context of the LDM.  Does whatever's
 * necessary before and after the fork to ensure correct behavior.  Terminates
 * the child process if the fork() was successful but an error occurs.
 *
 * Returns:
 *      0               Success.  The calling process is the child.
 *      -1              Failure.  "log_start()" called.
 *      else            PID of child process.  The calling process is the       
 *                      parent.
 */
pid_t ldmfork(void);

#ifdef __cplusplus
}
#endif

#endif
