#ifndef SHARED_COUNTER_H
#define SHARED_COUNTER_H

typedef struct SharedCounter	SharedCounter;

enum sc_error {
    SC_SYSTEM				/* system failure */
};

#endif
