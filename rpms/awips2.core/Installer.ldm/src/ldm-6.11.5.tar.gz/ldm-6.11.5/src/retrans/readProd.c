#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#define MAX_SZ 2048
#define ETB 0x17
#define INPUTDIR "/data/co/ddm/nwws_ack_pend"
#define OUTLOG "/data/ldm/logs/nwws_ack.log"

static char *PROGNAME="readProd";
void usage();

void usage()
{
  printf("\nusage:%s <filename>\n",PROGNAME);
  exit(1);
}

int main(int argc, char *argv[])
{
  int  linecnt=0,i,rc;
  char linebuf[MAX_SZ];
  char inbuf[MAX_SZ];
  FILE  *fd,*ofd;
  char *p,*msgid,*msg_id;
  char filename[256];
  char basedir[50];
  char logbuf[50];
  char timebuf[50];
  struct stat statbuf; 
  struct tm *tm;
  time_t dtime;
  int fstat;
/*  
  if( argc != 2){
    printf("Invalid numer of arguments");
    usage();
  }

  if((fd = fopen(argv[1],"r")) == NULL)
  {
    printf("Unable to open %s for reading\n",argv[1] );
    exit(-1);
  }
*/
  fd = stdin; /* for stdin */

  if((ofd = fopen(OUTLOG,"a")) == NULL)
  {
    printf("Unable to open %s for writing \n",OUTLOG );
    exit(-1);
  }
  
  dtime = time(NULL);
  tm = localtime(&dtime);
  sprintf(timebuf,"%2.2d/%2.2d/%4.4d %2.2d:%2.2d:%2.2d",tm->tm_mon+1,tm->tm_mday,tm->tm_year+1900,tm->tm_hour,tm->tm_min,tm->tm_sec);
  while(fgets(linebuf, MAX_SZ, fd) != NULL)
  {
    strcpy(inbuf,linebuf);
    fputs(linebuf,ofd);
    p = (char *) strtok(inbuf,"etb");
    if(p == NULL || p[0] != ETB){
        continue;
    }

     /* msgid=p+1;*/
      /*msg_id = (char *)malloc(strlen(msgid)+1);*/
      msg_id = (char *)malloc(strlen(p+1)+1);
      p++; 
      for(i=0; i < strlen(p) && isgraph(p[i]); i++){
        msg_id[i] = p[i];
      }
      msg_id[i]='\0';
     /* printf("\n new msg_id=%s %d %d \n",msg_id,strlen(msgid),strlen(msg_id));*/
/*      printf("\n new msg_id=%s %d %d \n",msg_id,strlen(msg_id));*/
     strcpy(basedir,INPUTDIR);
     sprintf(filename,"%s/%s",basedir,msg_id);
     printf("filename=%s\n",filename);
     if((fstat = stat(filename,&statbuf)) < 0){
       sprintf(logbuf,"%s Error %d (err=%s) Unable to stat %s. File NOT found.\n",timebuf, fstat,strerror(errno), filename);
       fputs(logbuf,ofd);
     } else {
        if(statbuf.st_mode & S_IFREG){
           sprintf(logbuf,"%s File %s located. Sending ACK\n",timebuf, filename);
           fputs(logbuf,ofd);
	   rc = unlink(filename);
	   if(rc < 0){
             sprintf(logbuf,"%s Unable to delete file %s.Error:%s",timebuf, filename,strerror(errno));
             fputs(logbuf,ofd);
	   }	
        }else{
           sprintf(logbuf,"%s File %s NOT valid\n",timebuf, filename);
           fputs(logbuf,ofd);
        }
    }

       
      free(msg_id); 

  }
  fclose(fd);
  fclose(ofd);
}
