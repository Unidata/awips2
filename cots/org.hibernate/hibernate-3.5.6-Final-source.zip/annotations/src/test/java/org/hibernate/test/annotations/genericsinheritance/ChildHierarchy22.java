package org.hibernate.test.annotations.genericsinheritance;

import javax.persistence.Entity;

@Entity
public class ChildHierarchy22 extends ChildHierarchy2<ParentHierarchy22> {

}
