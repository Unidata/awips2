//$Id: FirTree.java 14760 2008-06-11 07:33:15Z hardy.ferentschik $
package org.hibernate.test.annotations.id.entities;

import javax.persistence.Entity;

/**
 * @author Emmanuel Bernard
 */
@Entity
public class FirTree extends Tree {
}
