package org.hibernate.test.annotations.collectionelement;

public enum FavoriteFood {
	SUSHI,
	KUNGPAOCHICKEN,
	ROASTBEEF,
	PIZZA
}
