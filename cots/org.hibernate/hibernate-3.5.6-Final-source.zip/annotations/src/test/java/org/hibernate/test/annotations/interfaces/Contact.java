//$Id: Contact.java 14736 2008-06-04 14:23:42Z hardy.ferentschik $
package org.hibernate.test.annotations.interfaces;

/**
 * @author Emmanuel Bernard
 */
public interface Contact {
	Integer getId();

	String getName();
}
