// $Id: Planet.java 14785 2008-06-19 10:44:33Z hardy.ferentschik $
package org.hibernate.test.annotations.id.sequences.entities;

public enum Planet {
	MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE, PLUTO;
}
