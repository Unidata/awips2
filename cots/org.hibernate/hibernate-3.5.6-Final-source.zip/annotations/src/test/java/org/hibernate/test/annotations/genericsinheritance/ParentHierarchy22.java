package org.hibernate.test.annotations.genericsinheritance;

import javax.persistence.Entity;

@Entity
public class ParentHierarchy22 extends ParentHierarchy2<ChildHierarchy22> {

}
