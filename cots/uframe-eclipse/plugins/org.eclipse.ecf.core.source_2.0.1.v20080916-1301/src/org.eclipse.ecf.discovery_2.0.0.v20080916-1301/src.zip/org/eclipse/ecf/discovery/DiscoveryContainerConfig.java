/*******************************************************************************
 * Copyright (c) 2007 Versant Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Markus Kuppe (mkuppe <at> versant <dot> com) - initial API and implementation
 ******************************************************************************/
package org.eclipse.ecf.discovery;

import org.eclipse.ecf.core.identity.ID;

public class DiscoveryContainerConfig {

	private ID id;

	/**
	 * @param anID
	 */
	public DiscoveryContainerConfig(ID anID) {
		id = anID;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ecf.discovery.IContainerConfig#getID()
	 */
	public ID getID() {
		return id;
	}

}
