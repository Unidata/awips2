===============
:mod:`metpy.io`
===============

.. automodule:: metpy.io

.. toctree::

   cdm
   formats
