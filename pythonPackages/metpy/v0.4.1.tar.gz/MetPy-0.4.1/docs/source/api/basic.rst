******************
Basic Calculations
******************

.. automodule:: metpy.calc.basic
   :members:
   :undoc-members:
