===
CDM
===

:mod:`metpy.io.cdm`

.. automodule:: metpy.io.cdm
   :members:
   :special-members: __init__
