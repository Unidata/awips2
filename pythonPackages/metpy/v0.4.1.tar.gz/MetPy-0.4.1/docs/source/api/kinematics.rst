**********************
Kinematic Calculations
**********************

.. automodule:: metpy.calc.kinematics
   :members:
   :undoc-members:
