This is the place to add IPython notebook examples. These notebooks will
automatically be converted to standalone scripts and RST documentation.
*Note:* These should *not* have spaces in the files names, as that will break
Sphinx. Instead, use underscores, which will be converted to spaces for title
purposes.
