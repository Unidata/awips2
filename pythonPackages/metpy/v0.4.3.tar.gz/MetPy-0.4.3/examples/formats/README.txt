.. _formats_examples:

File Formats
------------

Examples using MetPy's support for reading various file formats.
