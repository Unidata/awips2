.. _examples-index:

MetPy Examples
==============


.. _general-examples:

General Examples
----------------

Examples of using a variety of MetPy's functionality together.
