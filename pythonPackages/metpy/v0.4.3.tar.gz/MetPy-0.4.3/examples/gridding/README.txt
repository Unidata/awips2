.. _gridding_examples:

Gridding
--------

Examples generating a grid of data from scattered point observations.
