Contributors
============

Alex Haberlie
- Point Interpolation
- resample_1d_nn

kpozsonyi
- Improved example gallery
- Coriolis parameter
- equivalent potential temperature
- saturation mixing ratio
- pressure to height using standard atmosphere
- More examples

J.R. Leeman
- LFC/EL calculation, curve intersection

Other Contributions
-------------------
Kevin Goebbert
Jonathan Helmus
Will Holmgren
Shawn Murdzek
mmorello1

Main Developers
---------------
Ryan May
Sean Arms
Eric Bruning
Patrick Marsh
