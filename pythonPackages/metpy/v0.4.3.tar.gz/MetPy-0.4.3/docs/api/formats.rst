============
File Formats
============

These classes provide support for reading data from specific formats.

NEXRAD
------
.. automodule:: metpy.io.nexrad
   :members:
   :special-members: __init__

GINI
----
.. automodule:: metpy.io.gini
   :members:
   :special-members: __init__

