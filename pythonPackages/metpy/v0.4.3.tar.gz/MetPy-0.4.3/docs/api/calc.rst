=================
:mod:`metpy.calc`
=================

.. automodule:: metpy.calc

These are the major groups of calculations available in MetPy:

.. toctree::

   basic
   kinematics
   thermo
   turbulence
