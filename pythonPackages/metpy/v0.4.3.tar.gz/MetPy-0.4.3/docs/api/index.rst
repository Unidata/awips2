.. _api-index:

#############
The MetPy API
#############

.. toctree::
   :maxdepth: 2

   constants
   units
   io
   calc
   plots

* :ref:`modindex`
* :ref:`genindex`
