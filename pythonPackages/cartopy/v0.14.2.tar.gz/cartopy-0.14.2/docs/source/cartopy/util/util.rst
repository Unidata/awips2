Miscellaneous cartopy utilities
===============================

.. automodule:: cartopy.util
    :members:
