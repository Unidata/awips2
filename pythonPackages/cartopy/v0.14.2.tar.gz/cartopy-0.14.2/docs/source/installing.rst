.. _installing:

******************
Installing Cartopy
******************

.. include:: ../../INSTALL
