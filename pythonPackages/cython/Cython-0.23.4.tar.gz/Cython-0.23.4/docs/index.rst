
Welcome to Cython's Documentation
=================================

Also see the current `in-development version <http://docs.cython.org/dev/>`_
of the documentation and the `Cython project homepage <http://cython.org/>`_.

.. toctree::
   :maxdepth: 2

   src/quickstart/index
   src/tutorial/index
   src/userguide/index
   src/reference/index
