from .pyximport import *

# replicate docstring
from .pyximport import __doc__
