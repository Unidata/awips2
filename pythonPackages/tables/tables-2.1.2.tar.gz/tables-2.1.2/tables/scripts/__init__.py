"""
Utility scripts for PyTables
============================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivan@selidor.net
:Created:  2005-12-01
:License:  BSD
:Revision: $Id: __init__.py 3698 2008-09-09 12:54:51Z faltet $

This package contains some modules which provide a ``main()`` function
(with no arguments), so that they can be used as scripts.
"""
