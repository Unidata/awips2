*************
Release Notes
*************

.. include:: ../release/1.3.0-notes.rst
