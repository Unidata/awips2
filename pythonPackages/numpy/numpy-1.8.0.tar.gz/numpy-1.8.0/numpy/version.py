
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.0'
version = '1.8.0'
full_version = '1.8.0'
git_revision = 'a60b3901cd635d28bef8328e83bafd35ce631e08'
release = True

if not release:
    version = full_version
